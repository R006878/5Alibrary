import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Search, 
  Plus, 
  Trash2, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  X, 
  Database, 
  Info,
  Calendar,
  Lock,
  LogOut,
  FolderOpen,
  ClipboardList,
  RefreshCw
} from 'lucide-react';
import { Book, User, BorrowRecord, AuditRecord } from './types.js';
import { apiFetch, generateCSV, downloadCSV } from './utils.js';

// Modular child components
import Header from './components/Header.jsx';
import SearchPanel from './components/SearchPanel.jsx';
import CatalogTable from './components/CatalogTable.jsx';
import BorrowReturnForm from './components/BorrowReturnForm.jsx';
import AdminPanel from './components/AdminPanel.jsx';

export default function App() {
  // Authentication State
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('lib_user');
    return saved ? JSON.parse(saved) : null;
  });

  // UI state
  const [activeTab, setActiveTab] = useState<'catalog' | 'circulation' | 'settings' | 'admin'>('catalog');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [dbStatus, setDbStatus] = useState<{ database: string; isSupabase: boolean } | null>(null);
  
  // Data State
  const [books, setBooks] = useState<Book[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [history, setHistory] = useState<BorrowRecord[]>([]);
  const [audits, setAudits] = useState<AuditRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Form State - Login
  const [loginId, setLoginId] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);

  // Form State - Change Password
  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');

  // Form State - Click-to-borrow interaction helper
  const [circBookId, setCircBookId] = useState<string>('');

  // Catalog Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Fetch initial data
  const fetchData = async () => {
    setIsLoading(true);
    try {
      const booksData = await apiFetch<Book[]>('/api/books');
      setBooks(booksData);

      const status = await apiFetch<{ database: string; isSupabase: boolean }>('/api/db-status');
      setDbStatus(status);

      if (user) {
        const historyData = await apiFetch<BorrowRecord[]>('/api/borrow/history');
        // Sort newest first
        setHistory(historyData.sort((a,b)=>b.borrow_date.localeCompare(a.borrow_date)));
        
        if (user.role === 'admin') {
          const usersData = await apiFetch<User[]>('/api/users');
          setUsers(usersData);
          const auditData = await apiFetch<AuditRecord[]>('/api/audit');
          setAudits(auditData);
        }
      }
    } catch (err: any) {
      showTemporaryError(err.message || '讀取資料失敗。');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const showTemporarySuccess = (msg: string) => {
    setSuccessMsg(msg);
    setErrorMsg('');
    setTimeout(() => setSuccessMsg(''), 5500);
  };

  const showTemporaryError = (msg: string) => {
    setErrorMsg(msg);
    setSuccessMsg('');
    setTimeout(() => setErrorMsg(''), 5500);
  };

  // Auth processing
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginId.trim() || !loginPassword.trim()) {
      showTemporaryError('請輸入員工編號與密碼。');
      return;
    }
    try {
      const res = await apiFetch<{ user: User }>('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: loginId.trim(), password: loginPassword }),
      });
      setUser(res.user);
      localStorage.setItem('lib_user', JSON.stringify(res.user));
      setShowLoginModal(false);
      setLoginId('');
      setLoginPassword('');
      showTemporarySuccess(`歡迎回來，${res.user.name}！`);
    } catch (err: any) {
      showTemporaryError(err.message || '登入驗證錯誤。');
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('lib_user');
    setActiveTab('catalog');
    showTemporarySuccess('已成功登出系統。');
  };

  // User Actions: Password Change
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmPassword) {
      showTemporaryError('所有密碼欄位皆為必填。');
      return;
    }
    if (newPassword !== confirmPassword) {
      showTemporaryError('兩次新密碼輸入不一致。');
      return;
    }
    try {
      await apiFetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: user?.id,
          currentPassword,
          newPassword,
        }),
      });
      showTemporarySuccess('密碼變更成功！請守護您的密碼安全。');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setActiveTab('catalog');
    } catch (err: any) {
      showTemporaryError(err.message || '密碼修改失敗。');
    }
  };

  // Admin Actions: Books Ledger Management
  const handleAddBook = async (id: string, title: string, author: string, category: string, purchaseYear: string) => {
    try {
      setIsLoading(true);
      await apiFetch('/api/books', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id,
          title,
          author,
          category,
          purchase_year: purchaseYear
        }),
      });
      showTemporarySuccess(`成功上架新書「${title}」並登錄購入年度：${purchaseYear}年！`);
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '新增書籍失敗。');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteBook = async (id: string, title: string) => {
    if (!window.confirm(`確定要將書籍「${title}」永久除名嗎？此操作不可逆。`)) return;
    try {
      setIsLoading(true);
      await apiFetch(`/api/books/${id}`, { method: 'DELETE' });
      showTemporarySuccess(`書籍「${title}」已被移除。`);
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '刪除書籍失敗。');
    } finally {
      setIsLoading(false);
    }
  };

  // Admin Actions: Member Directory Management
  const handleAddUser = async (id: string, name: string, role: 'admin' | 'user', passwordRaw: string) => {
    try {
      setIsLoading(true);
      await apiFetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id,
          name,
          role,
          password: passwordRaw,
        }),
      });
      showTemporarySuccess(`成功註冊新成員：${name} (${id.toUpperCase()})！`);
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '無法建立該成員。');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteUser = async (id: string, name: string) => {
    if (id.toLowerCase() === user?.id.toLowerCase()) {
      showTemporaryError('不允許刪除目前登入中的管理員帳號！');
      return;
    }
    if (!window.confirm(`確定要移除成員「${name} (${id})」嗎？他將失去所有存取權利。`)) return;
    try {
      setIsLoading(true);
      await apiFetch(`/api/users/${id}`, { method: 'DELETE' });
      showTemporarySuccess(`成員「${name}」已遭刪除。`);
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '成員刪除失敗。');
    } finally {
      setIsLoading(false);
    }
  };

  // Self-service: Lend & Return transactions
  const handleBorrow = async (bookId: string, userId: string, userName: string) => {
    try {
      setIsLoading(true);
      await apiFetch('/api/borrow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          book_id: bookId,
          user_id: userId,
          user_name: userName,
        }),
      });
      showTemporarySuccess('借出辦理成功！請悉心保管臨床用書並準時归還。');
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '借閱處理出錯。');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReturn = async (bookId: string) => {
    try {
      setIsLoading(true);
      await apiFetch('/api/return', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ book_id: bookId }),
      });
      showTemporarySuccess(`圖書歸還登記已正式入庫！`);
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '歸還處理出錯。');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitAudit = async (detailsList: { [bookId: string]: 'present' | 'missing' }) => {
    try {
      setIsLoading(true);
      const listPayload = Object.entries(detailsList).map(([book_id, status]) => ({
        book_id,
        status,
      }));

      await apiFetch('/api/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          auditor_id: user?.id,
          details: listPayload,
        }),
      });

      showTemporarySuccess('圖書稽核與點班明細表冊已正式更新上傳至資料儲存庫！');
      fetchData();
    } catch (err: any) {
      showTemporaryError(err.message || '點班提交發生故障錯誤。');
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportRecords = async (start: string, end: string) => {
    try {
      setIsLoading(true);
      const filteredRecords = await apiFetch<BorrowRecord[]>(`/api/export?startDate=${start}&endDate=${end}`);
      const csvStr = generateCSV(filteredRecords);
      const filename = `圖書流通紀錄報表_${start}_至_${end}.csv`;
      downloadCSV(csvStr, filename);
      showTemporarySuccess(`成功對照產生 ${filteredRecords.length} 筆借還紀錄檔！`);
    } catch (err: any) {
      showTemporaryError(err.message || '導出報表失敗。');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick select book to borrow when user clicks row in Catalog
  const handleQuickBookSelect = (bookId: string) => {
    if (user) {
      setCircBookId(bookId);
      setActiveTab('circulation');
    } else {
      showTemporaryError('請先點選右上角 [登入] 後才能辦理借書登記與流通。');
    }
  };

  // Filtering logic
  const filteredBooks = books.filter(b => {
    const query = searchQuery.toLowerCase().trim();
    
    // Check if query is 7-character employee pattern starting with R/E to query borrow ledger
    const matchesQuery = 
      b.title.toLowerCase().includes(query) || 
      b.id.toLowerCase().includes(query) ||
      (b.author && b.author.toLowerCase().includes(query)) ||
      (b.holder_id && b.holder_id.toLowerCase().includes(query)) ||
      (b.holder_name && b.holder_name.toLowerCase().includes(query));

    const matchesCategory = categoryFilter === 'All' || b.category === categoryFilter;
    
    let matchesStatus = true;
    if (statusFilter !== 'All') {
      if (statusFilter === 'available') matchesStatus = b.status === 'available';
      if (statusFilter === 'borrowed') matchesStatus = b.status === 'borrowed';
      if (statusFilter === 'maintenance_lost') matchesStatus = b.status === 'lost' || b.status === 'maintenance';
    }

    return matchesQuery && matchesCategory && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-[#f3f6f3] text-gray-800 flex flex-col justify-between select-none font-sans" id="container_app">
      
      {/* 1. HEADER HERO BAR */}
      <Header 
        user={user}
        dbStatus={dbStatus}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLoginClick={() => setShowLoginModal(true)}
        onLogout={handleLogout}
      />

      {/* TOAST SYSTEM ALERTS */}
      {successMsg && (
        <div className="bg-emerald-50 border-y border-emerald-200 py-3 text-center text-xs text-emerald-800 font-medium flex items-center justify-center space-x-2 animate-fade-in shrink-0" id="toast_success">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}
      {errorMsg && (
        <div className="bg-rose-50 border-y border-rose-250 py-3 text-center text-xs text-rose-800 font-medium flex items-center justify-center space-x-2 animate-fade-in shrink-0" id="toast_error">
          <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Sub Navigation Bar for members */}
      {user && (
        <nav className="bg-white border-b border-gray-200 py-2 shadow-sm shrink-0" id="sub_navigation_bar">
          <div className="max-w-7xl mx-auto px-4 flex space-x-1.5 overflow-x-auto">
            <button
              onClick={() => setActiveTab('catalog')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 ${
                activeTab === 'catalog'
                  ? 'bg-gray-800 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              圖書檢索
            </button>
            <button
              onClick={() => setActiveTab('circulation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 ${
                activeTab === 'circulation'
                  ? 'bg-gray-800 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              快速借閱與歸還
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 ${
                activeTab === 'settings'
                  ? 'bg-gray-800 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              修改密碼
            </button>
            {user.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 ${
                  activeTab === 'admin'
                    ? 'bg-[#107c41] text-white shadow-sm'
                    : 'text-emerald-750 bg-emerald-50 hover:bg-emerald-100'
                }`}
              >
                ⚙ 管理員系統後台
              </button>
            )}
          </div>
        </nav>
      )}

      {/* 2. MAIN VIEW ENGINE */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6 overflow-y-auto" id="main_viewport">
        {isLoading && (
          <div className="flex items-center justify-center space-x-1.5 text-xs text-gray-500 py-1" id="loading_spinner">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#107c41]" />
            <span>處理中，請稍候...</span>
          </div>
        )}

        {/* ========================================================
            VIEW A: CATALOG EXPLORE (PUBLIC + CLICK TO INTERACT)
            ======================================================== */}
        {activeTab === 'catalog' && (
          <div className="space-y-5" id="view_catalog_list">
            
            {/* Elegant Search Widget */}
            <SearchPanel 
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              categoryFilter={categoryFilter}
              setCategoryFilter={setCategoryFilter}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              books={books}
              viewMode={viewMode}
              setViewMode={setViewMode}
            />

            {/* Hint alert for non logged in */}
            {!user && (
              <div className="bg-blue-50/50 border border-blue-100 text-blue-750 p-3 rounded-xl text-xs flex items-start space-x-2 select-none">
                <span className="text-sm">💡</span>
                <span>
                  <strong>提示項目：</strong>本期公有閱覽服務完全對外開放，可直接輸入書名搜尋。同仁如果要<strong>線上辦理借書或還書</strong>，請點選右上角登入後，即可在列表中快速選取並自動帶入流通櫃檯辦理！
                </span>
              </div>
            )}

            {/* List header title & result count */}
            <div className="flex items-center justify-between text-xs text-gray-500 select-none px-0.5">
              <span>全館已找到 <strong className="text-gray-800">{filteredBooks.length}</strong> 本優質圖書</span>
              <span className="hidden sm:inline font-mono">系統即時更新</span>
            </div>

            {/* Pure Catalog Table or Bento Grid */}
            <CatalogTable 
              books={filteredBooks}
              viewMode={viewMode}
              onQuickBookSelect={handleQuickBookSelect}
            />

          </div>
        )}

        {/* ========================================================
            VIEW B: CIRCULATION TRANSACTIONS (MEMBERS)
            ======================================================== */}
        {activeTab === 'circulation' && user && (
          <div className="space-y-5 animate-fade-in" id="view_circulation_panel">
            <div className="bg-gray-800 text-white rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="space-y-1">
                <h3 className="font-semibold text-sm flex items-center space-x-1.5 text-emerald-400">
                  <span>🟢 已連結至病房流通櫃檯</span>
                </h3>
                <p className="text-xs text-gray-400 font-medium">現行經辦人: {user.name} ({user.id})</p>
              </div>
              <div className="text-[10px] bg-gray-700/60 text-gray-300 font-mono px-3 py-1 rounded">
                預定到期日: 借出 + 14 天
              </div>
            </div>

            <BorrowReturnForm 
              user={user}
              books={books}
              onBorrow={handleBorrow}
              onReturn={handleReturn}
              circBookId={circBookId}
              setCircBookId={setCircBookId}
              isLoading={isLoading}
            />

            {/* Users dynamic hold list */}
            <div className="bg-white border border-gray-220 rounded-2xl p-5 shadow-sm" id="borrower_hold_ledger">
              <h4 className="text-xs font-bold text-gray-400 tracking-wider uppercase border-b border-gray-100 pb-3 flex items-center justify-between">
                <span>您名下目前借用中、尚未歸還的圖書明細</span>
                <span className="font-mono text-gray-500 font-normal">
                  (已借用 {books.filter(b => b.holder_id?.toUpperCase() === user.id.toUpperCase() && b.status === 'borrowed').length} 本)
                </span>
              </h4>

              <div className="overflow-x-auto mt-4">
                <table className="w-full text-left border-collapse text-xs text-gray-700 font-sans">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200 text-gray-400 font-bold select-none">
                      <th className="px-4 py-2">書籍條碼</th>
                      <th className="px-4 py-2">熱門名稱</th>
                      <th className="px-4 py-2">專業分類</th>
                      <th className="px-4 py-2">辦理借期</th>
                      <th className="px-4 py-2 text-center">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {books.filter(b => b.holder_id?.toUpperCase() === user.id.toUpperCase() && b.status === 'borrowed').map(b => (
                      <tr key={b.id}>
                        <td className="px-4 py-2.5 font-mono font-bold text-gray-650">{b.id}</td>
                        <td className="px-4 py-2.5 font-medium text-gray-900">{b.title}</td>
                        <td className="px-4 py-2.5">{b.category}</td>
                        <td className="px-4 py-2.5 font-mono text-gray-500">{b.borrow_date}</td>
                        <td className="px-4 py-2.5 text-center">
                          <button
                            onClick={() => handleReturn(b.id)}
                            className="bg-red-50 text-red-600 hover:bg-red-100 px-3 py-1 border border-red-100 rounded text-[10px] font-semibold transition-colors"
                          >
                            立即歸還
                          </button>
                        </td>
                      </tr>
                    ))}
                    {books.filter(b => b.holder_id?.toUpperCase() === user.id.toUpperCase() && b.status === 'borrowed').length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center text-gray-400">目前您的借閱名冊中沒有未歸還記錄，好習慣，謝謝配合！</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            VIEW C: ACCOUNT SETTINGS (PASSWORD CHANGE)
            ======================================================== */}
        {activeTab === 'settings' && user && (
          <div className="max-w-md mx-auto bg-white border border-gray-250 rounded-2xl p-6 shadow-sm space-y-4 animate-fade-in" id="settings_password_reset">
            <h3 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center space-x-1.5 select-none">
              <Lock className="w-4 h-4 text-[#107c41]" />
              <span>修改同仁系統登入密碼</span>
            </h3>

            <form onSubmit={handleChangePassword} className="space-y-4" id="form_password_update">
              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1 select-none">請輸入：目前舊密碼</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-xs"
                  placeholder="舊有預設密碼"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1 select-none">請輸入：更變新密碼</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-xs"
                  placeholder="建立新密码"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1 select-none">請再次確認：新密碼</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-xs"
                  placeholder="重複鍵入以作校驗"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#107c41] hover:bg-[#0c6133] active:bg-[#0a4f29] text-white font-semibold py-2 px-4 rounded-lg text-xs transition-colors"
              >
                <span>儲存並重設密碼記錄</span>
              </button>
            </form>
          </div>
        )}

        {/* ========================================================
            VIEW D: ADMINISTRATIVE BACKEND (ADMIN-ONLY)
            ======================================================== */}
        {activeTab === 'admin' && user && user.role === 'admin' && (
          <AdminPanel 
            user={user}
            books={books}
            users={users}
            history={history}
            audits={audits}
            isLoading={isLoading}
            onAddBook={handleAddBook}
            onDeleteBook={handleDeleteBook}
            onAddUser={handleAddUser}
            onDeleteUser={handleDeleteUser}
            onExport={handleExportRecords}
            onSubmitAudit={handleSubmitAudit}
          />
        )}
      </main>

      {/* 3. SIGN-IN MODAL WINDOW */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-gray-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="modal_login_backdrop">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-gray-100 relative space-y-4 animate-scale-up" id="modal_login_window">
            
            <button 
              onClick={() => setShowLoginModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
              title="關閉"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-1 select-none">
              <span className="text-2xl">🏥</span>
              <h3 className="text-base font-semibold text-gray-900">5A 病房核心登入通道</h3>
              <p className="text-[11px] text-gray-400">請鍵入同仁代碼及密碼以開啟流通借閱與點班功能</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4" id="form_login_action">
              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">員工代號 (E.G. R006878 / E10001)</label>
                <input
                  type="text"
                  required
                  placeholder="病房工號ID"
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-mono uppercase bg-gray-50 text-gray-800"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">登入安全驗證密碼</label>
                <input
                  type="password"
                  required
                  placeholder="主機登錄密碼"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-800"
                />
              </div>

              <div className="text-[10px] text-gray-400 font-mono space-y-0.5 select-none bg-gray-50 p-2 rounded leading-snug">
                <div>🔑 <strong>預置測試工號資訊:</strong></div>
                <div>帳管(主管): <code className="bg-gray-150 py-0.2 px-0.8 text-rose-600 rounded">R006878</code> / 密碼: <code className="bg-gray-150 py-0.2 px-0.8 rounded">admin123</code></div>
                <div>常規(同仁): <code className="bg-gray-150 py-0.2 px-0.8 text-rose-600 rounded">E10001</code> / 密碼: <code className="bg-gray-150 py-0.2 px-0.8 rounded">user123</code></div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#107c41] hover:bg-[#0c6133] active:bg-[#0a4f29] text-white font-semibold py-2 px-4 rounded-lg text-xs transition-colors shadow-sm cursor-pointer"
                id="btn_submit_login"
              >
                <span>解鎖登入</span>
              </button>
            </form>

          </div>
        </div>
      )}

      {/* FOOTER METRICS INFO */}
      <footer className="bg-white border-t border-gray-200 py-3 text-center text-[10px] text-gray-400 shrink-0 font-sans select-none" id="footer_notes">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-1">
          <span>&copy; 5A 病房圖書資訊系統 🌟 一切權益保留</span>
          <span>儲存協議: 備援 SQL 資料流通</span>
        </div>
      </footer>

    </div>
  );
}
