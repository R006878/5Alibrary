import { Book, User, BorrowRecord, AuditRecord } from './types.js';

// Base API interactions
export async function apiFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  if (!res.ok) {
    let errMsg = `請求錯誤 (${res.status})`;
    try {
      const data = await res.json();
      errMsg = data.error || errMsg;
    } catch (_) {}
    throw new Error(errMsg);
  }
  return res.json() as Promise<T>;
}

export function generateCSV(records: BorrowRecord[]): string {
  if (records.length === 0) {
    return '無符合條件的借閱紀錄\n';
  }

  // UTF-8 BOM to prevent MS Excel Chinese character garbling
  const BOM = '\uFEFF';
  const headers = ['紀錄編號', '書籍編號', '書名', '借閱人編號', '借閱人姓名', '借出日期', '應還日期', '歸還日期', '狀態'];
  const rows = records.map((r) => [
    r.id,
    r.book_id,
    r.book_title.replace(/"/g, '""'), // Escape double quotes for CSV
    r.user_id,
    r.user_name.replace(/"/g, '""'),
    r.borrow_date,
    r.due_date || '',
    r.return_date || '',
    r.status === 'borrowed' ? '外借中' : r.status === 'returned' ? '已歸還' : '逾期',
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map((row) => row.map((val) => `"${val}"`).join(',')),
  ].join('\n');

  return BOM + csvContent;
}

export function downloadCSV(csvContent: string, fileName: string) {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
