import React from 'react';
import { Search, X, LayoutGrid, List } from 'lucide-react';
import { Book } from '../types.js';

interface SearchPanelProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  categoryFilter: string;
  setCategoryFilter: (category: string) => void;
  statusFilter: string;
  setStatusFilter: (status: string) => void;
  books: Book[];
  viewMode: 'list' | 'grid';
  setViewMode: (mode: 'list' | 'grid') => void;
}

export default function SearchPanel({
  searchQuery,
  setSearchQuery,
  categoryFilter,
  setCategoryFilter,
  statusFilter,
  setStatusFilter,
  books,
  viewMode,
  setViewMode
}: SearchPanelProps) {
  // Let's declare the exact 5 medical categories requested by user
  const medicalCategories = ['內科', '外科', '護理', '教學', '其他'];

  // Status statistics inside search panel dynamically computed
  const totalCount = books.length;
  const availableCount = books.filter(b => b.status === 'available').length;
  const borrowedCount = books.filter(b => b.status === 'borrowed').length;
  const maintenanceOrLostCount = books.filter(b => b.status === 'lost' || b.status === 'maintenance').length;

  return (
    <div className="bg-[#142d1b] rounded-2xl p-5 md:p-6 text-white shadow-md mx-auto max-w-7xl relative overflow-hidden" id="search_panel_box">
      
      {/* Decorative subtle texture/background details */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl -mr-12 -mt-12 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-36 h-36 bg-[#16512b]/15 rounded-full blur-2xl -ml-12 -mb-12 pointer-events-none"></div>

      <div className="relative space-y-4">
        {/* Panel Title */}
        <h2 className="text-[17px] font-medium tracking-wide flex items-center space-x-2 text-[#b7d3b9]" id="panel_header_title">
          <span className="text-[15px]">📖</span>
          <span>全館圖書檢索庫</span>
        </h2>

        {/* Big Search Input with Rounded corners */}
        <div className="relative w-full shadow-sm rounded-lg" id="panel_input_group">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="請輸入：書名，或輸入 7 碼員工編號查詢其借書單..."
            className="w-full pl-10 pr-10 py-3 bg-white text-gray-800 rounded-lg text-sm border-none focus:outline-none focus:ring-2 focus:ring-emerald-500 placeholder-gray-400 transition-all font-sans"
            id="panel_main_search"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-450 hover:text-gray-600 transition-colors"
              title="清除字串"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Row with Category select, status pills and grid toggle */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1" id="filter_controls_row">
          
          <div className="flex flex-wrap items-center gap-2" id="filter_group_left">
            {/* Category Filter Dropdown */}
            <div className="relative">
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="appearance-none bg-white text-gray-800 font-medium px-4 pr-8 py-1.5 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 cursor-pointer min-w-[95px] text-center"
              >
                <option value="All">所有分類</option>
                {medicalCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-600">
                <svg className="fill-current h-3 w-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </div>
            </div>

            {/* Status filtering pills */}
            <div className="flex flex-wrap items-center gap-1.5" id="status_capsules">
              <button
                onClick={() => setStatusFilter('All')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  statusFilter === 'All'
                    ? 'bg-[#294c34] text-white ring-1 ring-emerald-500'
                    : 'bg-[#1e3423] text-gray-300 hover:text-white hover:bg-[#25402b]'
                }`}
              >
                全部書籍 ({totalCount})
              </button>
              
              <button
                onClick={() => setStatusFilter('available')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  statusFilter === 'available'
                    ? 'bg-[#294c34] text-white ring-1 ring-emerald-500'
                    : 'bg-[#1e3423] text-gray-300 hover:text-white hover:bg-[#25402b]'
                }`}
              >
                在架上 ({availableCount})
              </button>

              <button
                onClick={() => setStatusFilter('borrowed')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  statusFilter === 'borrowed'
                    ? 'bg-[#294c34] text-white ring-1 ring-emerald-500'
                    : 'bg-[#1e3423] text-gray-300 hover:text-white hover:bg-[#25402b]'
                }`}
              >
                借出中 ({borrowedCount})
              </button>

              <button
                onClick={() => setStatusFilter('maintenance_lost')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  statusFilter === 'maintenance_lost'
                    ? 'bg-[#294c34] text-white ring-1 ring-emerald-500'
                    : 'bg-[#1e3423] text-gray-300 hover:text-white hover:bg-[#25402b]'
                }`}
              >
                保養/遺失 ({maintenanceOrLostCount})
              </button>
            </div>
          </div>

          {/* Grid/List View switcher - structured as white rounded button block */}
          <div className="flex items-center justify-end" id="filter_group_right">
            <div className="bg-white/95 p-1 rounded-lg flex items-center space-x-1 shadow-sm text-gray-700" id="layout_toggle_box">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-1 rounded transition-all ${viewMode === 'grid' ? 'bg-[#b7d3b9]/50 text-[#142d1b]' : 'hover:bg-gray-100 text-gray-400'}`}
                title="網格檢視"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <div className="w-[1px] h-3.5 bg-gray-200"></div>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-1 rounded transition-all ${viewMode === 'list' ? 'bg-[#b7d3b9]/50 text-[#142d1b]' : 'hover:bg-gray-100 text-gray-400'}`}
                title="列表檢視"
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
