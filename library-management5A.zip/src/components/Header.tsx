import React from 'react';
import { LogOut, User as UserIcon, Shield, Database } from 'lucide-react';
import { User } from '../types.js';

interface HeaderProps {
  user: User | null;
  dbStatus: { database: string; isSupabase: boolean } | null;
  activeTab: string;
  setActiveTab: (tab: 'catalog' | 'circulation' | 'settings' | 'admin') => void;
  onLoginClick: () => void;
  onLogout: () => void;
}

export default function Header({
  user,
  dbStatus,
  activeTab,
  setActiveTab,
  onLoginClick,
  onLogout
}: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-250 select-none shadow-sm sticky top-0 z-50 shrink-0" id="header_nav">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        
        {/* Brand Logo & Name */}
        <div 
          onClick={() => setActiveTab('catalog')} 
          className="flex items-center space-x-2 cursor-pointer transition-opacity hover:opacity-90" 
          id="brand_title"
        >
          <div className="text-[#107c41] font-bold text-lg font-sans tracking-wide">
            5A 圖書管理系統
          </div>
        </div>

        {/* Center Pill Tab as in image: 圖書檢索首頁 - active state styled */}
        <div className="flex justify-center items-center space-x-1" id="header_nav_center">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`px-3 sm:px-4 py-1.5 rounded-full text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
              activeTab === 'catalog'
                ? 'bg-[#e2f0d9] text-[#2c5c2d] hover:bg-[#d5ebd5]'
                : 'text-gray-500 hover:text-gray-950 hover:bg-gray-50'
            }`}
            id="tab_catalog_home"
          >
            圖書檢索首頁
          </button>

          {user && (
            <>
              <button
                onClick={() => setActiveTab('circulation')}
                className={`px-3 sm:px-4 py-1.5 rounded-full text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                  activeTab === 'circulation'
                    ? 'bg-[#e2f0d9] text-[#2c5c2d] hover:bg-[#d5ebd5]'
                    : 'text-gray-500 hover:text-gray-920 hover:bg-gray-50'
                }`}
                id="tab_circulation_home"
              >
                個人借閱書架
              </button>

              {user.role === 'admin' && (
                <button
                  onClick={() => setActiveTab('admin')}
                  className={`px-3 sm:px-4 py-1.5 rounded-full text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                    activeTab === 'admin'
                      ? 'bg-[#e2f0d9] text-[#2c5c2d] hover:bg-[#d5ebd5]'
                      : 'text-gray-500 hover:text-gray-920 hover:bg-gray-50'
                  }`}
                  id="tab_admin_home"
                >
                  系統後台管理
                </button>
              )}
            </>
          )}
        </div>

        {/* Right Side: Logged in status or Login green button */}
        <div className="flex items-center space-x-3" id="profile_actions">
          
          {/* DB Indicator shown subtly */}
          <div className="hidden lg:flex items-center space-x-1 text-xs text-gray-500 mr-2 bg-gray-50 px-2.5 py-1 rounded-full border border-gray-100">
            <span className={`w-1.5 h-1.5 rounded-full ${dbStatus?.isSupabase ? 'bg-emerald-500' : 'bg-amber-400'}`}></span>
            <span className="font-mono text-[10px] text-gray-600">{dbStatus ? (dbStatus.isSupabase ? 'Supabase' : '本地備援') : '偵測中...'}</span>
          </div>

          {user ? (
            <div className="flex items-center space-x-3 text-xs sm:text-sm text-gray-700 font-sans" id="login_user_display">
              <span className="font-semibold text-gray-900 tracking-wide">
                {user.name} (員編:{user.id})
              </span>
              <button 
                onClick={onLogout}
                className="text-rose-600 hover:text-rose-700 font-medium cursor-pointer transition-colors"
                title="登出系統"
                id="btn_logout"
              >
                登出
              </button>
            </div>
          ) : (
            <button
              onClick={onLoginClick}
              className="bg-[#107c41] hover:bg-[#0c6133] active:bg-[#0a4f29] text-white font-medium px-4 py-1.5 rounded-lg text-sm transition-all shadow-sm flex items-center space-x-1.5 border border-transparent cursor-pointer"
              id="btn_trigger_login"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>同仁登入</span>
            </button>
          )}
        </div>

      </div>
    </header>
  );
}
