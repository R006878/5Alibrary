import React from 'react';
import { Calendar, User2, MapPin, Tag, FileText, CheckCircle, AlertTriangle } from 'lucide-react';
import { Book } from '../types.js';

interface CatalogTableProps {
  books: Book[];
  viewMode: 'list' | 'grid';
  onQuickBookSelect?: (bookId: string) => void;
}

export default function CatalogTable({
  books,
  viewMode,
  onQuickBookSelect
}: CatalogTableProps) {
  if (books.length === 0) {
    return (
      <div className="bg-white border border-gray-200 rounded-2xl p-12 text-center text-gray-400 font-sans shadow-sm" id="empty_catalog_state">
        <FileText className="w-12 h-12 mx-auto text-gray-300 mb-3" />
        <h3 className="text-gray-700 font-medium text-sm">找不到符合條件的書籍</h3>
        <p className="text-xs text-gray-400 mt-1">請再嘗試輸入其他關鍵字（例如：書名、條碼、借閱人工號），或重設分類/狀態篩選鈕範疇。</p>
      </div>
    );
  }

  // Helper for status styling badges
  const getStatusBadge = (status: Book['status']) => {
    switch (status) {
      case 'available':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-750 border border-emerald-100">
            在庫 (可借閱)
          </span>
        );
      case 'borrowed':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-100">
            外借中
          </span>
        );
      case 'lost':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-750 border border-rose-100">
            點班缺漏 (遺失)
          </span>
        );
      case 'maintenance':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-750 border border-blue-100">
            保養重整中
          </span>
        );
      default:
        return null;
    }
  };

  // Helper for category custom color codes
  const getCategoryColor = (category: string) => {
    switch (category) {
      case '內科':
        return 'bg-blue-50 text-blue-750 border-blue-100';
      case '外科':
        return 'bg-purple-50 text-purple-750 border-purple-100';
      case '護理':
        return 'bg-teal-50 text-teal-750 border-teal-100';
      case '教學':
        return 'bg-indigo-50 text-indigo-750 border-indigo-100';
      case '其他':
      default:
        return 'bg-gray-100 text-gray-650 border-gray-200';
    }
  };

  if (viewMode === 'grid') {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" id="catalog_grid_container">
        {books.map(book => (
          <div 
            key={book.id}
            onClick={() => onQuickBookSelect?.(book.id)}
            className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md hover:border-gray-350 transition-all cursor-pointer flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              {/* Top metadata tags */}
              <div className="flex items-center justify-between gap-1 overflow-hidden">
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${getCategoryColor(book.category)} truncate shrink-0`}>
                  {book.category}
                </span>
                <span className="font-mono text-[10px] text-gray-400 font-semibold truncate shrink">
                  {book.id}
                </span>
              </div>
              
              {/* Title & Author */}
              <div>
                <h4 className="font-medium text-gray-900 text-sm line-clamp-2 hover:text-[#107c41]">
                  {book.title}
                </h4>
                <p className="text-[11px] text-gray-550 truncate mt-0.5" title={book.author}>
                  作者: {book.author}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-gray-100 space-y-1.5 text-[11px] text-gray-600">
              {/* Status Badge */}
              <div className="flex items-center justify-between">
                <span className="text-gray-400 text-[10px]">當前狀態</span>
                {getStatusBadge(book.status)}
              </div>

              {/* Purchase Year (購入年度) */}
              <div className="flex items-center justify-between">
                <span className="text-gray-400 text-[10px]">購入年度</span>
                <span className="font-medium text-gray-800 font-mono">
                  {book.purchase_year ? `${book.purchase_year} 年` : '未載明'}
                </span>
              </div>

              {/* Borrower details (借閱人) */}
              <div className="flex items-center justify-between">
                <span className="text-gray-400 text-[10px]">借閱人</span>
                <span className="font-semibold text-gray-800">
                  {book.status === 'borrowed' ? (
                    <span className="text-amber-800 font-sans flex items-center gap-0.5">
                      <User2 className="w-3 h-3 text-amber-600 inline" />
                      {book.holder_name || book.holder_id || '使用中'}
                    </span>
                  ) : (
                    <span className="text-gray-400">—</span>
                  )}
                </span>
              </div>

              {/* Last Audit */}
              {book.last_audit_date && (
                <div className="text-[10px] text-gray-400 text-right font-mono mt-1 pt-0.5">
                  點班: {book.last_audit_date}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm" id="catalog_table_container">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse font-sans">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 text-xs font-semibold uppercase tracking-wider select-none">
              <th className="px-6 py-3.5">條碼號</th>
              <th className="px-6 py-3.5">書名與作者</th>
              <th className="px-6 py-3.5">分類</th>
              <th className="px-6 py-3.5">狀態</th>
              <th className="px-6 py-3.5">購入年度</th>
              <th className="px-6 py-3.5">目前借閱人 / 保管人</th>
              <th className="px-6 py-3.5 text-center">本期上次點班日</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-150 text-xs">
            {books.map(book => (
              <tr 
                key={book.id} 
                onClick={() => onQuickBookSelect?.(book.id)}
                className="hover:bg-gray-50/70 transition-colors cursor-pointer"
              >
                <td className="px-6 py-3.5 font-mono font-semibold text-gray-650">
                  {book.id}
                </td>
                <td className="px-6 py-3.5">
                  <div className="font-semibold text-gray-900 text-sm">{book.title}</div>
                  <div className="text-[11px] text-gray-450 mt-0.5">作者: {book.author}</div>
                </td>
                <td className="px-6 py-3.5">
                  <span className={`inline-block text-[11px] font-bold px-2 py-0.5 rounded border ${getCategoryColor(book.category)}`}>
                    {book.category}
                  </span>
                </td>
                <td className="px-6 py-3.5">
                  {getStatusBadge(book.status)}
                </td>
                <td className="px-6 py-3.5 font-mono text-gray-700 text-sm">
                  {book.purchase_year ? `${book.purchase_year} 年` : '—'}
                </td>
                <td className="px-6 py-3.5">
                  {book.status === 'borrowed' ? (
                    <div className="space-y-0.5">
                      <div className="font-semibold text-amber-800 flex items-center gap-1">
                        <User2 className="w-3 h-3 text-amber-600 shrink-0" />
                        <span>{book.holder_name || '無記錄'}</span>
                        <span className="font-mono text-[10px] text-gray-400 bg-gray-100 px-1 rounded">({book.holder_id})</span>
                      </div>
                      <div className="text-[10px] text-gray-400 flex items-center gap-0.5">
                        <Calendar className="w-2.5 h-2.5 shrink-0" />
                        <span>借期: {book.borrow_date || '未登錄'}</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-gray-400">—</span>
                  )}
                </td>
                <td className="px-6 py-3.5 font-mono text-center text-gray-500">
                  {book.last_audit_date ?? '尚未點班'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
