import React, { useState } from 'react';
import { BookOpen, HelpCircle, CornerDownLeft, RefreshCw, BookmarkCheck } from 'lucide-react';
import { User, Book } from '../types.js';

interface BorrowReturnFormProps {
  user: User;
  books: Book[];
  onBorrow: (bookId: string, userId: string, userName: string) => Promise<void>;
  onReturn: (bookId: string) => Promise<void>;
  circBookId: string;
  setCircBookId: (id: string) => void;
  isLoading: boolean;
}

export default function BorrowReturnForm({
  user,
  books,
  onBorrow,
  onReturn,
  circBookId,
  setCircBookId,
  isLoading
}: BorrowReturnFormProps) {
  const [returnBarcode, setReturnBarcode] = useState('');

  const handleBorrowSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!circBookId.trim()) return;
    await onBorrow(circBookId.trim(), user.id, user.name);
    setCircBookId('');
  };

  const handleReturnSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnBarcode.trim()) return;
    await onReturn(returnBarcode.trim());
    setReturnBarcode('');
  };

  // Find dynamic selection helper
  const selectedBook = books.find(b => b.id.toLowerCase() === circBookId.toLowerCase().trim());

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="circulation_actions_grid">
      
      {/* Borrow Form container */}
      <div className="bg-white border border-gray-250 rounded-2xl p-6 shadow-sm flex flex-col justify-between" id="card_borrow_box">
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center space-x-2 select-none">
            <span className="text-[#107c41] text-base">📤</span>
            <span>辦理圖書借閱登記</span>
          </h4>

          <form onSubmit={handleBorrowSubmit} className="space-y-4" id="form_borrow_service">
            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1.5 uppercase select-none">
                一、 書籍條碼編號 / BARCODE ID
              </label>
              <input
                type="text"
                required
                value={circBookId}
                onChange={(e) => setCircBookId(e.target.value)}
                placeholder="例: B000001 (可在上方搜尋器或網卡中點選書籍)"
                className="w-full px-3 py-2 bg-gray-55/70 border border-gray-200 rounded-lg text-xs font-mono uppercase focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:bg-white text-gray-850"
                id="input_borrow_barcode"
                disabled={isLoading}
              />
              
              {/* Dynamic Book Preview Card */}
              {selectedBook && (
                <div className="mt-2.5 p-3 rounded-lg bg-emerald-50/50 border border-emerald-100 flex items-start space-x-2.5">
                  <span className="text-lg">📖</span>
                  <div className="text-xs overflow-hidden">
                    <div className="font-semibold text-emerald-950 truncate">{selectedBook.title}</div>
                    <div className="text-gray-450 mt-0.5 truncate">作者: {selectedBook.author} ({selectedBook.category})</div>
                    <div className="mt-1">
                      <span className={`inline-block text-[10px] font-semibold px-1.5 rounded-full ${
                        selectedBook.status === 'available' ? 'bg-emerald-150 text-emerald-800' : 'bg-red-100 text-red-800'
                      }`}>
                        狀態: {selectedBook.status === 'available' ? '在庫可借' : '無法借用'}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1.5 uppercase select-none">
                二、 借閱者姓名工號 (系統自動鎖定)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  disabled
                  value={user.id}
                  className="w-full px-3 py-2 bg-gray-100/80 border border-gray-200 rounded-lg text-xs text-gray-500 font-mono"
                />
                <input
                  type="text"
                  disabled
                  value={user.name}
                  className="w-full px-3 py-2 bg-gray-100/80 border border-gray-200 rounded-lg text-xs text-gray-500 font-sans"
                />
              </div>
            </div>

            <div className="text-[10px] text-gray-400 leading-normal flex items-start space-x-1 p-2 bg-gray-50 rounded">
              <HelpCircle className="w-3.5 h-3.5 text-gray-300 shrink-0 mt-0.5" />
              <span>注意：借閱期預設最長為 14 天。每次借閱需要遵循科室規定妥善保管。確定借出後系統會即時更改流通主機。</span>
            </div>

            <button
              type="submit"
              disabled={isLoading || (selectedBook ? selectedBook.status !== 'available' : false)}
              className="w-full bg-[#107c41] hover:bg-[#0c6133] disabled:bg-gray-200 disabled:text-gray-450 text-white font-semibold py-2.5 px-4 rounded-lg text-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm mt-3"
              id="btn_borrow_confirm"
            >
              {isLoading ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <BookmarkCheck className="w-3.5 h-3.5" />
              )}
              <span>確認圖書出庫借領</span>
            </button>
          </form>
        </div>
      </div>

      {/* Return Form container */}
      <div className="bg-white border border-gray-250 rounded-2xl p-6 shadow-sm flex flex-col justify-between" id="card_return_box">
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center space-x-2 select-none">
            <span className="text-rose-600 text-base">📥</span>
            <span>歸還圖書登載</span>
          </h4>

          <form onSubmit={handleReturnSubmit} className="space-y-4" id="form_return_service">
            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1.5 uppercase select-none">
                輸入要歸還的書籍條碼 / BARCODE ID
              </label>
              <input
                type="text"
                required
                value={returnBarcode}
                onChange={(e) => setReturnBarcode(e.target.value)}
                placeholder="請掃描或手動鍵入還書條碼 (例: B000002)"
                className="w-full px-3 py-2 bg-gray-55/70 border border-gray-200 rounded-lg text-xs font-mono uppercase focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:bg-white text-gray-850"
                id="input_return_barcode"
                disabled={isLoading}
              />
            </div>

            <div className="text-[10px] text-gray-400 leading-normal bg-gray-50 p-3 rounded-lg space-y-1">
              <span className="font-semibold text-gray-500 block">🔹 圖書釋出說明：</span>
              <p>1. 本功能支援自主歸還，可代班上其他同仁將已借用之臨床書本放回原在架處並點選送出。</p>
              <p>2. 歸還手續完成後，該書本的狀態將會即時回復為在庫，且名下的借用人關係也將一併清空解除。</p>
            </div>

            <button
              type="submit"
              disabled={isLoading || !returnBarcode.trim()}
              className="w-full bg-[#107c41] hover:bg-[#0c6133] disabled:bg-gray-200 disabled:text-gray-450 text-white font-semibold py-2.5 px-4 rounded-lg text-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm mt-3"
              id="btn_return_confirm"
            >
              {isLoading ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <CornerDownLeft className="w-3.5 h-3.5" />
              )}
              <span>立即提交歸還</span>
            </button>
          </form>
        </div>
      </div>

    </div>
  );
}
