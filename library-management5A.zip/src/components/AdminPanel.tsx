import React, { useState } from 'react';
import { 
  Book as BookIcon, 
  User as UserIcon, 
  Trash2, 
  CheckCircle, 
  AlertTriangle, 
  Plus, 
  BarChart, 
  Download,
  Shield,
  ClipboardList,
  FolderOpen
} from 'lucide-react';
import { Book, User, BorrowRecord, AuditRecord } from '../types.js';

interface AdminPanelProps {
  user: User;
  books: Book[];
  users: User[];
  history: BorrowRecord[];
  audits: AuditRecord[];
  isLoading: boolean;
  onAddBook: (id: string, title: string, author: string, category: string, purchaseYear: string) => Promise<void>;
  onDeleteBook: (id: string, title: string) => Promise<void>;
  onAddUser: (id: string, name: string, role: 'admin' | 'user', passwordRaw: string) => Promise<void>;
  onDeleteUser: (id: string, name: string) => Promise<void>;
  onExport: (startDate: string, endDate: string) => Promise<void>;
  onSubmitAudit: (details: { [key: string]: 'present' | 'missing' }) => Promise<void>;
}

export default function AdminPanel({
  user,
  books,
  users,
  history,
  audits,
  isLoading,
  onAddBook,
  onDeleteBook,
  onAddUser,
  onDeleteUser,
  onExport,
  onSubmitAudit
}: AdminPanelProps) {
  const [subTab, setSubTab] = useState<'books' | 'users' | 'records' | 'audit'>('books');

  // Book Add Form State
  const [addBookId, setAddBookId] = useState('');
  const [addBookTitle, setAddBookTitle] = useState('');
  const [addBookAuthor, setAddBookAuthor] = useState('');
  const [addBookCategory, setAddBookCategory] = useState('內科'); // Default to clinical Category
  const [addBookPurchaseYear, setAddBookPurchaseYear] = useState(() => new Date().getFullYear().toString());

  // User Add Form State
  const [addUserId, setAddUserId] = useState('');
  const [addUserName, setAddUserName] = useState('');
  const [addUserRole, setAddUserRole] = useState<'admin' | 'user'>('user');
  const [addUserPassword, setAddUserPassword] = useState('');

  // Export dates
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Audit state
  const [auditChecks, setAuditChecks] = useState<{ [bookId: string]: 'present' | 'missing' }>({});
  const [auditScanId, setAuditScanId] = useState('');
  const [showSummaryModal, setShowSummaryModal] = useState(false);

  // Categories definition
  const medicalCategories = ['內科', '外科', '護理', '教學', '其他'];

  const handleAddBookSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addBookId.trim() || !addBookTitle.trim() || !addBookAuthor.trim() || !addBookPurchaseYear.trim()) return;
    await onAddBook(
      addBookId.trim(),
      addBookTitle.trim(),
      addBookAuthor.trim(),
      addBookCategory,
      addBookPurchaseYear.trim()
    );
    setAddBookId('');
    setAddBookTitle('');
    setAddBookAuthor('');
  };

  const handleAddUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addUserId.trim() || !addUserName.trim() || !addUserPassword) return;
    await onAddUser(
      addUserId.trim(),
      addUserName.trim(),
      addUserRole,
      addUserPassword
    );
    setAddUserId('');
    setAddUserName('');
    setAddUserPassword('');
  };

  const handleAuditToggle = (bookId: string, status: 'present' | 'missing') => {
    setAuditChecks(prev => ({
      ...prev,
      [bookId]: status
    }));
  };

  const handleAuditScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const barcode = auditScanId.trim().toUpperCase();
    if (!barcode) return;
    const targetBook = books.find(b => b.id.toUpperCase() === barcode);
    if (targetBook) {
      setAuditChecks(prev => ({
        ...prev,
        [targetBook.id]: 'present'
      }));
      setAuditScanId('');
    } else {
      alert(`找不到與條碼「${barcode}」匹配的書籍。`);
    }
  };

  const initializeAuditDetails = () => {
    const fresh: { [bId: string]: 'present' | 'missing' } = {};
    books.forEach(b => {
      fresh[b.id] = b.status === 'lost' ? 'missing' : 'present';
    });
    setAuditChecks(fresh);
  };

  const handleAuditCommit = async () => {
    const finalDetails = { ...auditChecks };
    // Make sure books not checked explicitly default
    books.forEach(b => {
      if (!finalDetails[b.id]) {
        finalDetails[b.id] = b.status === 'lost' ? 'missing' : 'present';
      }
    });
    await onSubmitAudit(finalDetails);
  };

  return (
    <div className="space-y-5" id="view_admin_panel">
      {/* Admin sub-header with tabs */}
      <div className="bg-white border border-gray-200 rounded-xl p-1 shadow-sm flex flex-wrap items-center gap-1 select-none" id="admin_sub_nav">
        <button
          onClick={() => setSubTab('books')}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            subTab === 'books' ? 'bg-[#107c41] text-white' : 'text-gray-600 hover:bg-gray-50'
          }`}
        >
          館藏書目維護
        </button>
        <button
          onClick={() => setSubTab('users')}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            subTab === 'users' ? 'bg-[#107c41] text-white' : 'text-gray-600 hover:bg-gray-50'
          }`}
        >
          成員權限名冊
        </button>
        <button
          onClick={() => setSubTab('records')}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            subTab === 'records' ? 'bg-[#107c41] text-white' : 'text-gray-600 hover:bg-gray-50'
          }`}
        >
          借閱報表導出
        </button>
        <button
          onClick={() => {
            initializeAuditDetails();
            setSubTab('audit');
          }}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            subTab === 'audit' ? 'bg-amber-600 text-white' : 'text-amber-700 hover:bg-amber-50'
          }`}
        >
          📖 全館點班稽核
        </button>
      </div>

      {/* SUB-TAB 1: BOOK MAINTENANCE */}
      {subTab === 'books' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="panel_admin_books_grid">
          {/* Add Book Form card */}
          <div className="bg-white border border-gray-250 rounded-2xl p-6 shadow-sm h-fit" id="admin_add_book_wrap">
            <h4 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center space-x-1.5 select-none">
              <Plus className="w-4 h-4 text-[#107c41]" />
              <span>上架添置全館新書</span>
            </h4>

            <form onSubmit={handleAddBookSubmit} className="space-y-4 mt-4" id="form_add_book">
              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">書籍條碼 (BARCODE ID / UNIQUE KEY)</label>
                <input
                  type="text"
                  required
                  placeholder="例: B000006"
                  value={addBookId}
                  onChange={(e) => setAddBookId(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-mono text-gray-800 bg-gray-55/40"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">書名名稱 (TITLE)</label>
                <input
                  type="text"
                  required
                  placeholder="請輸入完整醫學書名..."
                  value={addBookTitle}
                  onChange={(e) => setAddBookTitle(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-800"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">主要作者 (AUTHOR)</label>
                <input
                  type="text"
                  required
                  placeholder="例: Harrison, Cherry..."
                  value={addBookAuthor}
                  onChange={(e) => setAddBookAuthor(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-800"
                />
              </div>

              {/* Clinical Category constraints - 內科,外科,護理,教學,其他 */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">科室專業分類 (CATEGORY)</label>
                <select
                  value={addBookCategory}
                  onChange={(e) => setAddBookCategory(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 bg-white rounded-lg text-xs text-gray-800 focus:outline-none"
                >
                  {medicalCategories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Purchase Year Added to Add Form! */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">購入年度 (PURCHASE YEAR)</label>
                <input
                  type="text"
                  required
                  placeholder="例: 2026 或 民國 115"
                  value={addBookPurchaseYear}
                  onChange={(e) => setAddBookPurchaseYear(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-800"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#107c41] hover:bg-[#0c6133] active:bg-[#0a4f29] text-white font-semibold py-2 rounded-lg text-xs transition-colors flex items-center justify-center space-x-1"
              >
                <span>確認新增上架</span>
              </button>
            </form>
          </div>

          {/* Ledger Table */}
          <div className="bg-white border border-gray-220 rounded-2xl p-5 shadow-sm lg:col-span-2 overflow-hidden" id="admin_books_table_wrap">
            <h4 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center justify-between select-none">
              <span>現存圖書目錄明細 ({books.length} 本)</span>
              <span className="text-[10px] text-gray-400 font-mono">Ledger Database View</span>
            </h4>

            <div className="overflow-x-auto mt-4 max-h-[460px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase select-none">
                    <th className="px-4 py-2.5">條碼</th>
                    <th className="px-4 py-2.5">書名與作者</th>
                    <th className="px-4 py-2.5">分類</th>
                    <th className="px-4 py-2.5">購入年度</th>
                    <th className="px-4 py-2.5">當前借用狀態</th>
                    <th className="px-4 py-2.5 text-center">操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {books.map(b => (
                    <tr key={b.id} className="hover:bg-gray-50/50">
                      <td className="px-4 py-3 font-mono font-bold text-gray-650">{b.id}</td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-gray-900">{b.title}</div>
                        <div className="text-[10px] text-gray-400">{b.author}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded text-[10px] font-semibold">{b.category}</span>
                      </td>
                      <td className="px-4 py-3 font-mono text-gray-600 text-sm">{b.purchase_year || '—'}</td>
                      <td className="px-4 py-3">
                        {b.status === 'available' ? (
                          <span className="text-emerald-700 font-semibold">在庫</span>
                        ) : b.status === 'borrowed' ? (
                          <span className="text-amber-700 font-semibold" title={`工號 ${b.holder_id}`}>
                            借予 {b.holder_name || b.holder_id}
                          </span>
                        ) : (
                          <span className="text-rose-600 font-semibold">缺漏</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => onDeleteBook(b.id, b.title)}
                          disabled={b.status === 'borrowed'}
                          className="text-gray-400 hover:text-rose-600 p-1 rounded transition-colors disabled:opacity-30 disabled:hover:text-gray-450"
                          title={b.status === 'borrowed' ? '外借中書籍不可移除' : '移除此書'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: MEMBER REGISTER */}
      {subTab === 'users' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="panel_admin_users_grid">
          {/* Add Staff form */}
          <div className="bg-white border border-gray-250 rounded-2xl p-6 shadow-sm h-fit" id="admin_add_user_wrap">
            <h4 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center space-x-1.5 select-none">
              <Plus className="w-4 h-4 text-[#107c41]" />
              <span>註冊新同仁權限</span>
            </h4>

            <form onSubmit={handleAddUserSubmit} className="space-y-4 mt-4" id="form_add_user">
              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">員工病房工號 (ID - 英文+數字)</label>
                <input
                  type="text"
                  required
                  placeholder="例: R006878"
                  value={addUserId}
                  onChange={(e) => setAddUserId(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-mono text-gray-800 uppercase bg-gray-55/40"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">同仁真實姓名 (NAME)</label>
                <input
                  type="text"
                  required
                  placeholder="例: 李護理師"
                  value={addUserName}
                  onChange={(e) => setAddUserName(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-800"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">角色權限 (ROLE)</label>
                <div className="flex gap-4 text-xs mt-1">
                  <label className="inline-flex items-center space-x-1 cursor-pointer">
                    <input 
                      type="radio" 
                      name="userRole" 
                      value="user" 
                      checked={addUserRole === 'user'} 
                      onChange={() => setAddUserRole('user')}
                    />
                    <span>一般成員</span>
                  </label>
                  <label className="inline-flex items-center space-x-1 cursor-pointer">
                    <input 
                      type="radio" 
                      name="userRole" 
                      value="admin" 
                      checked={addUserRole === 'admin'} 
                      onChange={() => setAddUserRole('admin')}
                    />
                    <span className="text-amber-700 font-semibold">系統管理員</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 mb-1 select-none">登入初始密碼 (PASSWORD)</label>
                <input
                  type="password"
                  required
                  placeholder="例: minpw123"
                  value={addUserPassword}
                  onChange={(e) => setAddUserPassword(e.target.value)}
                  className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-800"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#107c41] hover:bg-[#0c6133] active:bg-[#0a4f29] text-white font-semibold py-2 rounded-lg text-xs transition-colors flex items-center justify-center space-x-1"
              >
                <span>確認註冊建立</span>
              </button>
            </form>
          </div>

          {/* Members Table */}
          <div className="bg-white border border-gray-220 rounded-2xl p-5 shadow-sm lg:col-span-2 overflow-hidden" id="admin_users_table_wrap">
            <h4 className="text-sm font-semibold text-gray-800 border-b border-gray-150 pb-3 flex items-center justify-between select-none">
              <span>現任同仁權限名冊 ({users.length} 位)</span>
              <span className="text-[10px] text-gray-400 font-mono">User Ledger Directory</span>
            </h4>

            <div className="overflow-x-auto mt-4 max-h-[460px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase select-none">
                    <th className="px-4 py-2.5">病房工號</th>
                    <th className="px-4 py-2.5">使用者姓名</th>
                    <th className="px-4 py-2.5">系統職級角色</th>
                    <th className="px-4 py-2.5 text-center">永久註銷</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {users.map(u => (
                    <tr key={u.id} className="hover:bg-gray-50/50">
                      <td className="px-4 py-3 font-mono font-bold text-gray-650">{u.id}</td>
                      <td className="px-4 py-3 font-medium text-gray-900">{u.name}</td>
                      <td className="px-4 py-3">
                        {u.role === 'admin' ? (
                          <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-100 font-semibold text-[10px]">
                            🔔 系統最高管理員
                          </span>
                        ) : (
                          <span className="text-gray-600 bg-gray-50 px-2 py-0.5 rounded border border-gray-100 text-[10px]">
                            一般同仁
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => onDeleteUser(u.id, u.name)}
                          disabled={u.id.toLowerCase() === user.id.toLowerCase()}
                          className="text-gray-400 hover:text-rose-600 p-1 rounded transition-colors disabled:opacity-35"
                          title="登出中管理員不可自刪"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: REPORTS EXPORT */}
      {subTab === 'records' && (
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm space-y-6" id="panel_admin_reports">
          <div className="border-b border-gray-150 pb-4">
            <h4 className="text-sm font-semibold text-gray-800">臨床書籍外流通借還報表匯出 (Excel 相容 UTF-8 專用 CSV)</h4>
            <p className="text-xs text-gray-450 mt-1">選定要調閱的核心日期範圍即可導出本地或 Supabase 上的最新流通實況紀錄。</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end" id="report_date_inputs">
            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1.5 select-none">起始追溯日期 (START DATE)</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1.5 select-none">結束截止日期 (END DATE)</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-xs"
              />
            </div>

            <button
              onClick={() => onExport(startDate, endDate)}
              disabled={isLoading || !startDate || !endDate}
              className="bg-[#107c41] hover:bg-[#0c6133] disabled:bg-gray-200 text-white font-semibold py-2 px-6 rounded-lg text-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer h-9 select-none"
              id="btn_export_action"
            >
              <Download className="w-3.5 h-3.5" />
              <span>產生報表並下載 CSV</span>
            </button>
          </div>

          {/* Historical Log list */}
          <div className="border-t border-gray-150 pt-5 space-y-3">
            <h5 className="text-xs font-semibold text-gray-700">最近 10 次同仁借閱流通流水帳日誌</h5>
            <div className="overflow-x-auto rounded-lg border border-gray-200 max-h-[290px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-gray-50 border-b border-gray-200 font-bold text-gray-500 uppercase select-none">
                  <tr>
                    <th className="px-4 py-2">借期</th>
                    <th className="px-4 py-2">同仁與工號</th>
                    <th className="px-4 py-2">借用圖書</th>
                    <th className="px-4 py-2">歸還狀態</th>
                    <th className="px-4 py-2 text-right">流水號</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-gray-700">
                  {history.slice(0, 10).map((h, i) => (
                    <tr key={h.id || i} className="hover:bg-gray-50/50">
                      <td className="px-4 py-2.5 font-mono text-gray-500">{h.borrow_date}</td>
                      <td className="px-4 py-2.5">
                        <span className="font-semibold text-gray-800">{h.user_name}</span>
                        <span className="font-mono text-gray-400 text-[10px] ml-1">({h.user_id})</span>
                      </td>
                      <td className="px-4 py-2.5 font-medium text-gray-900">{h.book_title}</td>
                      <td className="px-4 py-2.5">
                        {h.status === 'borrowed' ? (
                          <span className="text-amber-700 font-semibold bg-amber-50 px-1.5 py-0.5 rounded text-[10px]">使用中</span>
                        ) : (
                          <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded text-[10px]">
                            已歸還 ({h.return_date})
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono text-[10px] text-gray-400">{h.id.slice(0, 10)}</td>
                    </tr>
                  ))}
                  {history.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-gray-400">尚無任何借還登記紀錄。</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: INTERACTIVE INVENTORY AUDIT (圖書點班) */}
      {subTab === 'audit' && (
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm space-y-4" id="panel_admin_audit">
          <div className="border-b border-gray-150 pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 select-none">
            <div>
              <h4 className="text-sm font-semibold text-gray-800">臨床精實自主「圖書稽核與點班」查核中心</h4>
              <p className="text-[11px] text-gray-450 mt-1">
                預設所有在庫及借出書籍皆設定為「在架在店(present)」。請利用下方勾選鈕，將實體病房書架上「無故查無此書 / 遺失」的項目，標記為「遺失缺漏(missing)」。
              </p>
            </div>
            <div className="bg-amber-50 text-amber-800 text-[10px] px-3 py-1 rounded-full border border-amber-200 font-semibold w-fit">
              🔑 主管/點班人員: {user.name}
            </div>
          </div>

          {/* Quick barcode search/scan in active audit mode */}
          <form onSubmit={handleAuditScanSubmit} className="flex gap-2 max-w-md items-end" id="form_audit_scan">
            <div className="flex-1">
              <label className="block text-[10px] font-bold text-gray-400 mb-1">
                手動點盤條碼輸入 / 快速掃描器欄 (BARCODE SCAN)
              </label>
              <input
                type="text"
                value={auditScanId}
                onChange={(e) => setAuditScanId(e.target.value)}
                placeholder="請輸入條碼，按 Enter 自動設其為在架"
                className="w-full px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs font-mono uppercase"
              />
            </div>
            <button 
              type="submit"
              className="bg-gray-800 text-white font-medium px-4 py-1.5 rounded-lg text-xs h-8 border border-transparent hover:bg-gray-900 cursor-pointer"
            >
              登載在架
            </button>
          </form>

          {/* Interactive Checklist matrix */}
          <div className="border border-gray-150 rounded-xl overflow-hidden mt-2">
            <div className="max-h-[350px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-gray-50 border-b border-gray-200 font-bold text-gray-500 uppercase select-none sticky top-0">
                  <tr>
                    <th className="px-4 py-2.5">條碼</th>
                    <th className="px-4 py-2.5">專業分類</th>
                    <th className="px-4 py-2.5">書名與當前流通狀態</th>
                    <th className="px-4 py-2.5">購入年度</th>
                    <th className="px-4 py-2.5 text-center">盤點實體狀態稽核</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {books.map(b => {
                    const currentStatus = auditChecks[b.id] || 'present';
                    return (
                      <tr key={b.id} className="hover:bg-gray-50/40">
                        <td className="px-4 py-3 font-mono font-bold text-gray-650">{b.id}</td>
                        <td className="px-4 py-3">
                          <span className="bg-gray-50 text-gray-600 px-1.5 py-0.5 rounded text-[10px] border border-gray-100">{b.category}</span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-gray-800">{b.title}</div>
                          <div className="text-[10.5px] text-gray-400 mt-0.5 mt-0.5">
                            {b.status === 'borrowed' ? (
                              <span className="text-amber-800">
                                ⚠ 同仁 {b.holder_name || b.holder_id} 借用中 (借期 {b.borrow_date})
                              </span>
                            ) : b.status === 'available' ? (
                              <span className="text-emerald-700">在庫</span>
                            ) : (
                              <span className="text-rose-600 font-medium">標記為遺失</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 font-mono text-gray-650">{b.purchase_year || '—'}</td>
                        <td className="px-4 py-3 text-center">
                          <div className="inline-flex rounded-lg border border-gray-200 p-0.5 bg-gray-50" id={`audit_toggle_${b.id}`}>
                            <button
                              type="button"
                              onClick={() => handleAuditToggle(b.id, 'present')}
                              className={`px-3 py-1 rounded text-[10px] font-semibold transition-all cursor-pointer ${
                                currentStatus === 'present'
                                  ? 'bg-[#107c41] text-white shadow-sm'
                                  : 'text-gray-550 hover:text-gray-900 bg-transparent'
                              }`}
                            >
                              實體在架上
                            </button>
                            <button
                              type="button"
                              onClick={() => handleAuditToggle(b.id, 'missing')}
                              className={`px-3 py-1 rounded text-[10px] font-semibold transition-all cursor-pointer ${
                                currentStatus === 'missing'
                                  ? 'bg-rose-600 text-white shadow-sm'
                                  : 'text-gray-550 hover:text-red-700 bg-transparent'
                              }`}
                            >
                              點班缺漏 / 遺失
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="pt-4 flex items-center justify-between border-t border-gray-150 select-none">
            <span className="text-xs text-gray-400 font-mono">
              點盤核實: {Object.values(auditChecks).filter(v => v === 'present').length} 本在庫 / {Object.values(auditChecks).filter(v => v === 'missing').length} 本缺漏
            </span>
            
            <button
              onClick={handleAuditCommit}
              disabled={isLoading || books.length === 0}
              className="bg-amber-600 hover:bg-amber-700 text-white font-semibold py-2 px-6 rounded-lg text-xs transition-colors shadow flex items-center gap-1 cursor-pointer"
            >
              <CheckCircle className="w-3.5 h-3.5" />
              <span>提交本期點班表冊 (更新實體庫存)</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
