export interface User {
  id: string; // 員工編號, e.g., R006878 (1 letter + digits)
  name: string;
  role: 'admin' | 'user';
}

export interface Book {
  id: string; // 書籍條碼/編號
  title: string;
  author: string;
  category: string;
  status: 'available' | 'borrowed' | 'lost' | 'maintenance';
  holder_id?: string | null; // 目前借用人員工編號
  holder_name?: string | null; // 目前借用人姓名
  borrow_date?: string | null;
  last_audit_date?: string | null; // 上次點班日期
  purchase_year?: string | null; // 購入年度
}

export interface BorrowRecord {
  id: string;
  book_id: string;
  book_title: string;
  user_id: string;
  user_name: string;
  borrow_date: string;
  return_date?: string | null;
  due_date?: string | null;
  status: 'borrowed' | 'returned' | 'overdue';
}

export interface AuditRecord {
  id: string;
  audit_date: string;
  auditor_id: string;
  auditor_name: string;
  total_books: number;
  present_books: number;
  missing_books: number;
  details: { book_id: string; title: string; status: 'present' | 'missing' }[];
}
