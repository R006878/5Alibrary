-- ========================================================
-- SUPABASE POSTGRESQL TABLE SCHEMAS FOR LIBRARY MANAGEMENT
-- ========================================================
-- 預期執行指令：請將下述 SQL 語句複製貼上至您 Supabase 專案的「SQL Editor」中，並按下「Run」即可完成部署！

-- 1. 建立「使用者 / 員工」資料表 (users)
CREATE TABLE IF NOT EXISTS public.users (
    id TEXT PRIMARY KEY,                       -- 員工編號 (例如: R006878, E10001)
    name TEXT NOT NULL,                        -- 姓名
    role TEXT NOT NULL CHECK (role IN ('admin', 'user')), -- 角色
    password_hash TEXT NOT NULL,               -- SHA-256 加密後密碼
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. 建立「書籍館藏」資料表 (books)
CREATE TABLE IF NOT EXISTS public.books (
    id TEXT PRIMARY KEY,                       -- 書籍條碼或編號
    title TEXT NOT NULL,                       -- 書名
    author TEXT NOT NULL,                      -- 作者
    category TEXT NOT NULL,                    -- 分類
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'borrowed', 'lost', 'maintenance')), -- 狀態
    holder_id TEXT REFERENCES public.users(id) ON DELETE SET NULL, -- 目前借用人 ID
    holder_name TEXT,                          -- 目前借用人姓名快照
    borrow_date TEXT,                          -- 借閱日期 (YYYY-MM-DD)
    last_audit_date TEXT,                      -- 上次點班日期 (YYYY-MM-DD)
    purchase_year TEXT,                        -- 購入年度 (民國年或西元年, 例如: 2026 或 115)
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. 建立「借閱及歸還流通紀錄」資料表 (borrow_records)
CREATE TABLE IF NOT EXISTS public.borrow_records (
    id TEXT PRIMARY KEY,                       -- 紀錄邊碼 UUID 或自訂 ID
    book_id TEXT NOT NULL,                     -- 關聯書籍
    book_title TEXT NOT NULL,                  -- 當下書名快照
    user_id TEXT NOT NULL,                     -- 借用人工號
    user_name TEXT NOT NULL,                   -- 借用人姓名
    borrow_date TEXT NOT NULL,                 -- 登記借出日 (YYYY-MM-DD)
    due_date TEXT,                             -- 應歸還日期 (YYYY-MM-DD)
    return_date TEXT,                          -- 實際歸還日 (YYYY-MM-DD)
    status TEXT NOT NULL DEFAULT 'borrowed' CHECK (status IN ('borrowed', 'returned', 'overdue')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. 建立「圖書清冊稽核/點班歷史」資料表 (audit_records)
CREATE TABLE IF NOT EXISTS public.audit_records (
    id TEXT PRIMARY KEY,                       -- 點班查盤紀錄 ID
    audit_date TEXT NOT NULL,                  -- 點班日期 (YYYY-MM-DD)
    auditor_id TEXT NOT NULL,                  -- 查驗人員工編號
    auditor_name TEXT NOT NULL,                -- 查驗人姓名
    total_books INTEGER NOT NULL DEFAULT 0,    -- 盤存之總書籍數
    present_books INTEGER NOT NULL DEFAULT 0,  -- 實體在庫在架數量
    missing_books INTEGER NOT NULL DEFAULT 0,  -- 當期實體缺漏數量
    details JSONB NOT NULL,                    -- 詳細狀態對應表 (包含各本書籍編號, 書名與該期查核狀態字串)
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ========================================================
-- 預設初始種子資料播種 (Seed Data)
-- ========================================================

-- 注意：SHA-256 加密密碼與 Node.js crypt 相容：
-- 管理員帳號 R006878 預設密碼為: admin123  (hash: 2407530511874220b33cb7922d4f2bc187e14fb57a53de70ab0357f722fd727a)
-- 一般使用者 E10001 預設密碼為: user123   (hash: 13ee0061e878570f438848d7c92b23a73c1fec3bcf4476602375fae8006d649d)
-- 一般使用者 E10002 預設密碼為: user123   (hash: 13ee0061e878570f438848d7c92b23a73c1fec3bcf4476602375fae8006d649d)

INSERT INTO public.users (id, name, role, password_hash)
VALUES 
('R006878', '圖書館管理員', 'admin', '2407530511874220b33cb7922d4f2bc187e14fb57a53de70ab0357f722fd727a'),
('E10001', '張小明', 'user', '13ee0061e878570f438848d7c92b23a73c1fec3bcf4476602375fae8006d649d'),
('E10002', '王小華', 'user', '13ee0061e878570f438848d7c92b23a73c1fec3bcf4476602375fae8006d649d')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.books (id, title, author, category, status, last_audit_date, purchase_year, holder_id, holder_name, borrow_date)
VALUES 
('B000001', '哈利遜內科學 (Harrison Principles of Internal Medicine)', 'Harrison', '內科', 'available', '2026-06-01', '2024', NULL, NULL, NULL),
('B000002', '臨床外科手冊 (Surgical Secrets)', 'Alden H. Harken', '外科', 'borrowed', '2026-06-01', '2023', 'E10001', '張小明', '2026-06-05'),
('B000003', '當代護理學 (Contemporary Nursing)', 'Barbara Cherry', '護理', 'available', '2026-06-02', '2025', NULL, NULL, NULL),
('B000004', '醫學臨床教學指引 (Medical Teaching Guide)', 'Dent', '教學', 'available', '2026-06-02', '2024', NULL, NULL, NULL),
('B000005', '醫院精實管理 (Lean Hospital Operations)', 'Marc Baker', '其他', 'lost', '2026-05-25', '2022', NULL, NULL, NULL)
ON CONFLICT (id) DO NOTHING;

-- 啟用 RLS 與公開讀取 / 權限讀寫規則：
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.borrow_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_records ENABLE ROW LEVEL SECURITY;

-- 簡易開放式原則 (或依據您內部專案的安全配置)：
CREATE POLICY "Allow Service & Public Read/Write on everything" 
ON public.users FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow Service & Public Read/Write on books" 
ON public.books FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow Service & Public Read/Write on borrow_records" 
ON public.borrow_records FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow Service & Public Read/Write on audit_records" 
ON public.audit_records FOR ALL USING (true) WITH CHECK (true);
