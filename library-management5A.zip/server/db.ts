import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Book, User, BorrowRecord, AuditRecord } from '../src/types.js';

// Environment variables
const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_KEY = process.env.SUPABASE_KEY || process.env.SUPABASE_ANON_KEY || '';

// Database State
let supabase: SupabaseClient | null = null;
const isSupabaseConfigured = !!(SUPABASE_URL && SUPABASE_KEY);

if (isSupabaseConfigured) {
  try {
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    console.log('Successfully connected to Supabase Database!');
  } catch (error) {
    console.error('Failed to initialize Supabase client:', error);
  }
} else {
  console.log('Supabase credentials not found. Falling back to local JSON database storage.');
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Interface for local JSON database structure
interface Schema {
  users: { id: string; passwordHash: string; name: string; role: 'admin' | 'user' }[];
  books: Book[];
  borrowRecords: BorrowRecord[];
  auditRecords: AuditRecord[];
}

// Simple deterministic hash helper using Node.js built-in crypto
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Seed helper for initial data
const getInitialSchema = (): Schema => {
  return {
    users: [
      {
        id: 'R006878', // Default admin using the user's ID
        name: '圖書館管理員',
        role: 'admin',
        passwordHash: hashPassword('admin123'), // Default secure and easy password
      },
      {
        id: 'E10001',
        name: '張小明',
        role: 'user',
        passwordHash: hashPassword('user123'),
      },
      {
        id: 'E10002',
        name: '王小華',
        role: 'user',
        passwordHash: hashPassword('user123'),
      },
    ],
    books: [
      {
        id: 'B000001',
        title: '哈利遜內科學 (Harrison Principles of Internal Medicine)',
        author: 'Harrison',
        category: '內科',
        status: 'available',
        last_audit_date: '2026-06-01',
        purchase_year: '2024',
      },
      {
        id: 'B000002',
        title: '臨床外科手冊 (Surgical Secrets)',
        author: 'Alden H. Harken',
        category: '外科',
        status: 'borrowed',
        holder_id: 'E10001',
        holder_name: '張小明',
        borrow_date: '2026-06-05',
        last_audit_date: '2026-06-01',
        purchase_year: '2023',
      },
      {
        id: 'B000003',
        title: '當代護理學 (Contemporary Nursing)',
        author: 'Barbara Cherry',
        category: '護理',
        status: 'available',
        last_audit_date: '2026-06-02',
        purchase_year: '2025',
      },
      {
        id: 'B000004',
        title: '醫學臨床教學指引 (Medical Teaching Guide)',
        author: 'Dent',
        category: '教學',
        status: 'available',
        last_audit_date: '2026-06-02',
        purchase_year: '2024',
      },
      {
        id: 'B000005',
        title: '醫院精實管理 (Lean Hospital Operations)',
        author: 'Marc Baker',
        category: '其他',
        status: 'lost',
        last_audit_date: '2026-05-25',
        purchase_year: '2022',
      },
    ],
    borrowRecords: [
      {
        id: 'REC-001',
        book_id: 'B000002',
        book_title: 'Design Patterns: Elements of Reusable Object-Oriented Software',
        user_id: 'E10001',
        user_name: '張小明',
        borrow_date: '2026-06-05',
        status: 'borrowed',
        due_date: '2026-06-19',
      },
      {
        id: 'REC-002',
        book_id: 'B000001',
        book_title: 'Clean Code: A Handbook of Agile Software Craftsmanship',
        user_id: 'E10002',
        user_name: '王小華',
        borrow_date: '2026-05-10',
        return_date: '2026-05-24',
        status: 'returned',
        due_date: '2026-05-24',
      },
    ],
    auditRecords: [
      {
        id: 'AUD-001',
        audit_date: '2026-06-01',
        auditor_id: 'R006878',
        auditor_name: '圖書館管理員',
        total_books: 5,
        present_books: 4,
        missing_books: 1,
        details: [
          { book_id: 'B000001', title: 'Clean Code', status: 'present' },
          { book_id: 'B000002', title: 'Design Patterns', status: 'present' },
          { book_id: 'B000003', title: 'The Pragmatic Programmer', status: 'present' },
          { book_id: 'B000004', title: 'Refactoring', status: 'present' },
          { book_id: 'B000005', title: '人月神話 (The Mythical Man-Month)', status: 'missing' },
        ],
      },
    ],
  };
};

// Ensure JSON db exists and has data
function initializeLocalDb() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(getInitialSchema(), null, 2), 'utf-8');
  }
}

// Load JSON db
function readLocalDb(): Schema {
  initializeLocalDb();
  try {
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading local JSON db, regenerating initial structure:', err);
    const initial = getInitialSchema();
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
}

// Save JSON db
function writeLocalDb(data: Schema) {
  initializeLocalDb();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

export const dbService = {
  getIsSupabaseConfigured(): boolean {
    return isSupabaseConfigured;
  },

  // --- USERS OPERATIONS ---
  async getUsers(): Promise<User[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('users')
        .select('id, name, role');
      if (error) {
        console.error('Supabase getUsers error:', error);
        // Fallback to local
      } else if (data) {
        return data as User[];
      }
    }
    const db = readLocalDb();
    return db.users.map(({ id, name, role }) => ({ id, name, role }));
  },

  async getUser(id: string) {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      if (error) {
        console.error('Supabase getUser error:', error);
      } else if (data) {
        return {
          id: data.id,
          name: data.name,
          role: data.role as 'admin' | 'user',
          passwordHash: data.password_hash || data.passwordHash,
        };
      }
    }
    const db = readLocalDb();
    const user = db.users.find((u) => u.id.toLowerCase() === id.toLowerCase());
    return user || null;
  },

  async createUser(user: User, passwordRaw: string): Promise<User> {
    const hashed = hashPassword(passwordRaw);
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('users')
        .insert([{
          id: user.id,
          name: user.name,
          role: user.role,
          password_hash: hashed,
        }])
        .select();
      if (error) {
        console.error('Supabase createUser error, using local fallback:', error);
      } else if (data && data[0]) {
        return {
          id: data[0].id,
          name: data[0].name,
          role: data[0].role as 'admin' | 'user',
        };
      }
    }
    
    const db = readLocalDb();
    if (db.users.some(u => u.id.toLowerCase() === user.id.toLowerCase())) {
      throw new Error(`員工編號 ${user.id} 已經存在。`);
    }
    
    db.users.push({
      id: user.id,
      name: user.name,
      role: user.role,
      passwordHash: hashed,
    });
    writeLocalDb(db);
    return user;
  },

  async deleteUser(id: string): Promise<boolean> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase
        .from('users')
        .delete()
        .eq('id', id);
      if (error) {
        console.error('Supabase deleteUser error:', error);
      } else {
        return true;
      }
    }
    const db = readLocalDb();
    const index = db.users.findIndex((u) => u.id.toLowerCase() === id.toLowerCase());
    if (index === -1) return false;
    db.users.splice(index, 1);
    writeLocalDb(db);
    return true;
  },

  async updateUserPassword(id: string, passwordRaw: string): Promise<boolean> {
    const hashed = hashPassword(passwordRaw);
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase
        .from('users')
        .update({ password_hash: hashed })
        .eq('id', id);
      if (error) {
        console.error('Supabase updateUserPassword error:', error);
      } else {
        return true;
      }
    }
    const db = readLocalDb();
    const user = db.users.find((u) => u.id.toLowerCase() === id.toLowerCase());
    if (!user) return false;
    user.passwordHash = hashed;
    writeLocalDb(db);
    return true;
  },

  // --- BOOKS OPERATIONS ---
  async getBooks(): Promise<Book[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('books')
        .select('*')
        .order('id', { ascending: true });
      if (error) {
        console.error('Supabase getBooks error:', error);
      } else if (data) {
        return data as Book[];
      }
    }
    const db = readLocalDb();
    return db.books;
  },

  async getBook(id: string): Promise<Book | null> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('books')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      if (error) {
        console.error('Supabase getBook error:', error);
      } else if (data) {
        return data as Book;
      }
    }
    const db = readLocalDb();
    const book = db.books.find((b) => b.id === id);
    return book || null;
  },

  async createBook(book: Book): Promise<Book> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('books')
        .insert([{
          id: book.id,
          title: book.title,
          author: book.author,
          category: book.category,
          status: book.status,
          holder_id: book.holder_id,
          holder_name: book.holder_name,
          borrow_date: book.borrow_date,
          last_audit_date: book.last_audit_date,
          purchase_year: book.purchase_year,
        }])
        .select();
      if (error) {
        console.error('Supabase createBook error:', error);
      } else if (data && data[0]) {
        return data[0] as Book;
      }
    }
    const db = readLocalDb();
    if (db.books.some(b => b.id === book.id)) {
      throw new Error(`書籍編號/條碼 ${book.id} 已經存在。`);
    }
    db.books.push(book);
    writeLocalDb(db);
    return book;
  },

  async updateBook(id: string, fields: Partial<Book>): Promise<Book | null> {
    if (isSupabaseConfigured && supabase) {
      const updatePayload: any = {};
      if (fields.title !== undefined) updatePayload.title = fields.title;
      if (fields.author !== undefined) updatePayload.author = fields.author;
      if (fields.category !== undefined) updatePayload.category = fields.category;
      if (fields.status !== undefined) updatePayload.status = fields.status;
      if (fields.holder_id !== undefined) updatePayload.holder_id = fields.holder_id;
      if (fields.holder_name !== undefined) updatePayload.holder_name = fields.holder_name;
      if (fields.borrow_date !== undefined) updatePayload.borrow_date = fields.borrow_date;
      if (fields.last_audit_date !== undefined) updatePayload.last_audit_date = fields.last_audit_date;
      if (fields.purchase_year !== undefined) updatePayload.purchase_year = fields.purchase_year;

      const { data, error } = await supabase
        .from('books')
        .update(updatePayload)
        .eq('id', id)
        .select();
      if (error) {
        console.error('Supabase updateBook error:', error);
      } else if (data && data[0]) {
        return data[0] as Book;
      }
    }
    const db = readLocalDb();
    const idx = db.books.findIndex((b) => b.id === id);
    if (idx === -1) return null;
    db.books[idx] = { ...db.books[idx], ...fields };
    writeLocalDb(db);
    return db.books[idx];
  },

  async deleteBook(id: string): Promise<boolean> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase
        .from('books')
        .delete()
        .eq('id', id);
      if (error) {
        console.error('Supabase deleteBook error:', error);
      } else {
        return true;
      }
    }
    const db = readLocalDb();
    const idx = db.books.findIndex((b) => b.id === id);
    if (idx === -1) return false;
    db.books.splice(idx, 1);
    writeLocalDb(db);
    return true;
  },

  // --- BORROW RECORDS ---
  async getBorrowRecords(): Promise<BorrowRecord[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('borrow_records')
        .select('*')
        .order('borrow_date', { ascending: false });
      if (error) {
        console.error('Supabase getBorrowRecords error:', error);
      } else if (data) {
        return data as BorrowRecord[];
      }
    }
    const db = readLocalDb();
    return db.borrowRecords;
  },

  async createBorrowRecord(record: BorrowRecord): Promise<BorrowRecord> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('borrow_records')
        .insert([{
          id: record.id,
          book_id: record.book_id,
          book_title: record.book_title,
          user_id: record.user_id,
          user_name: record.user_name,
          borrow_date: record.borrow_date,
          return_date: record.return_date,
          due_date: record.due_date,
          status: record.status,
        }])
        .select();
      if (error) {
        console.error('Supabase createBorrowRecord error:', error);
      } else if (data && data[0]) {
        return data[0] as BorrowRecord;
      }
    }
    const db = readLocalDb();
    db.borrowRecords.unshift(record);
    writeLocalDb(db);
    return record;
  },

  async updateBorrowRecord(id: string, fields: Partial<BorrowRecord>): Promise<BorrowRecord | null> {
    if (isSupabaseConfigured && supabase) {
      const updatePayload: any = {};
      if (fields.return_date !== undefined) updatePayload.return_date = fields.return_date;
      if (fields.status !== undefined) updatePayload.status = fields.status;

      const { data, error } = await supabase
        .from('borrow_records')
        .update(updatePayload)
        .eq('id', id)
        .select();
      if (error) {
        console.error('Supabase updateBorrowRecord error:', error);
      } else if (data && data[0]) {
        return data[0] as BorrowRecord;
      }
    }
    const db = readLocalDb();
    const idx = db.borrowRecords.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    db.borrowRecords[idx] = { ...db.borrowRecords[idx], ...fields };
    writeLocalDb(db);
    return db.borrowRecords[idx];
  },

  // --- AUDIT RECORDS ---
  async getAuditRecords(): Promise<AuditRecord[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('audit_records')
        .select('*')
        .order('audit_date', { ascending: false });
      if (error) {
        console.error('Supabase getAuditRecords error:', error);
      } else if (data) {
        // details object might be JSON string depending on PG driver
        return data.map((item: any) => ({
          ...item,
          details: typeof item.details === 'string' ? JSON.parse(item.details) : item.details,
        })) as AuditRecord[];
      }
    }
    const db = readLocalDb();
    return db.auditRecords;
  },

  async createAuditRecord(record: AuditRecord): Promise<AuditRecord> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('audit_records')
        .insert([{
          id: record.id,
          audit_date: record.audit_date,
          auditor_id: record.auditor_id,
          auditor_name: record.auditor_name,
          total_books: record.total_books,
          present_books: record.present_books,
          missing_books: record.missing_books,
          details: typeof record.details === 'object' ? JSON.stringify(record.details) : record.details,
        }])
        .select();
      if (error) {
        console.error('Supabase createAuditRecord error:', error);
      } else if (data && data[0]) {
        return {
          ...data[0],
          details: typeof data[0].details === 'string' ? JSON.parse(data[0].details) : data[0].details,
        } as AuditRecord;
      }
    }
    const db = readLocalDb();
    db.auditRecords.unshift(record);
    writeLocalDb(db);
    return record;
  },
};
