import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { dbService, hashPassword } from './server/db.js';
import { Book, User, BorrowRecord, AuditRecord } from './src/types.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON request body parser
  app.use(express.json());

  // Logging middleware
  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  });

  // --- API ROUTES ---

  // Connection Info Endpoint
  app.get('/api/db-status', (req, res) => {
    const isSupabase = dbService.getIsSupabaseConfigured();
    res.json({
      status: 'ok',
      database: isSupabase ? 'Supabase (PostgreSQL)' : 'Local Database Fallback (JSON)',
      isSupabase,
    });
  });

  // Authentication API
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { id, password } = req.body;
      if (!id || !password) {
        return res.status(400).json({ error: '請輸入員工編號與密碼。' });
      }

      const user = await dbService.getUser(id);
      if (!user) {
        return res.status(401).json({ error: '員工編號不存在！' });
      }

      const hash = hashPassword(password);
      if (user.passwordHash !== hash) {
        return res.status(401).json({ error: '密碼錯誤！' });
      }

      // Return user without password hash
      res.json({
        user: {
          id: user.id,
          name: user.name,
          role: user.role,
        }
      });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: '伺服器登入處理失敗。' });
    }
  });

  // Change Password API (Self Service)
  app.post('/api/auth/change-password', async (req, res) => {
    try {
      const { id, currentPassword, newPassword } = req.body;
      if (!id || !currentPassword || !newPassword) {
        return res.status(400).json({ error: '欄位填寫不完整。' });
      }

      const user = await dbService.getUser(id);
      if (!user) {
        return res.status(404).json({ error: '使用者不存在。' });
      }

      if (user.passwordHash !== hashPassword(currentPassword)) {
        return res.status(400).json({ error: '目前密碼驗證錯誤。' });
      }

      await dbService.updateUserPassword(id, newPassword);
      res.json({ message: '密碼修改成功！' });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: '變更密碼失敗。' });
    }
  });

  // Users List (Admin Only)
  app.get('/api/users', async (req, res) => {
    try {
      // In real prod, verify authorization headers. For app completeness:
      const users = await dbService.getUsers();
      res.json(users);
    } catch (err) {
      res.status(500).json({ error: '無法讀取使用者清單。' });
    }
  });

  // Add User (Admin Only)
  app.post('/api/users', async (req, res) => {
    try {
      const { id, name, role, password } = req.body;
      if (!id || !name || !role || !password) {
        return res.status(400).json({ error: '所有欄位均為必填。' });
      }

      // ID Validation: starts with letter, followed by digits
      const idPattern = /^[A-Za-z]\d+$/;
      if (!idPattern.test(id)) {
        return res.status(400).json({ error: '員工編號格式不符 (首碼須為英文字母，後續為數字)。' });
      }

      // Check existence
      const exists = await dbService.getUser(id);
      if (exists) {
        return res.status(400).json({ error: `員工編號 ${id} 已被註冊。` });
      }

      const newUser: User = {
        id: id.toUpperCase(), // Auto-uppercase the leading letter
        name,
        role: role as 'admin' | 'user',
      };

      await dbService.createUser(newUser, password);
      res.json({ message: '使用者建立成功！', user: newUser });
    } catch (err: any) {
      res.status(500).json({ error: err.message || '建立成員失敗。' });
    }
  });

  // Delete User (Admin Only)
  app.delete('/api/users/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await dbService.deleteUser(id);
      if (success) {
        res.json({ message: '成員刪除成功！' });
      } else {
        res.status(404).json({ error: '找無此成員。' });
      }
    } catch (err) {
      res.status(500).json({ error: '刪除成員失敗。' });
    }
  });

  // Books list (Available to all)
  app.get('/api/books', async (req, res) => {
    try {
      const books = await dbService.getBooks();
      res.json(books);
    } catch (err) {
      res.status(500).json({ error: '無法取得書籍清單。' });
    }
  });

  // Add Book (Admin Only)
  app.post('/api/books', async (req, res) => {
    try {
      const { id, title, author, category, purchase_year } = req.body;
      if (!id || !title || !author || !category) {
        return res.status(400).json({ error: '所有書籍欄位均為必填。' });
      }

      const exists = await dbService.getBook(id);
      if (exists) {
        return res.status(400).json({ error: `書籍編號/條碼 ${id} 已經存在。` });
      }

      const newBook: Book = {
        id,
        title,
        author,
        category,
        status: 'available',
        last_audit_date: new Date().toISOString().split('T')[0],
        purchase_year: purchase_year || new Date().getFullYear().toString(),
      };

      await dbService.createBook(newBook);
      res.json({ message: '書籍新增成功！', book: newBook });
    } catch (err: any) {
      res.status(500).json({ error: err.message || '新增書籍失敗。' });
    }
  });

  // Edit Book (Admin Only)
  app.put('/api/books/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const book = await dbService.updateBook(id, req.body);
      if (!book) {
        return res.status(404).json({ error: '找無此書籍。' });
      }
      res.json({ message: '書籍更新成功！', book });
    } catch (err: any) {
      res.status(500).json({ error: '更新書籍失敗。' });
    }
  });

  // Delete Book (Admin Only)
  app.delete('/api/books/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await dbService.deleteBook(id);
      if (success) {
        res.json({ message: '書籍刪除成功！' });
      } else {
        res.status(404).json({ error: '找無此書籍。' });
      }
    } catch (err) {
      res.status(500).json({ error: '刪除書籍失敗。' });
    }
  });

  // Borrow Book API (Self Service or Admin)
  app.post('/api/borrow', async (req, res) => {
    try {
      const { book_id, user_id, user_name } = req.body;
      if (!book_id || !user_id || !user_name) {
        return res.status(400).json({ error: '請提供書籍條碼、借用人員工編號及姓名。' });
      }

      // Verify book
      const book = await dbService.getBook(book_id);
      if (!book) {
        return res.status(404).json({ error: '找無此書籍編號/條碼。' });
      }
      if (book.status !== 'available') {
        return res.status(400).json({ error: `此書目前狀態為「${book.status === 'borrowed' ? '外借中' : book.status === 'lost' ? '遺失' : '整理維護中'}」，無法借閱。` });
      }

      // Verify or record user
      const user = await dbService.getUser(user_id);
      if (!user) {
        return res.status(404).json({ error: `無此借書人，請確認員工編號。` });
      }

      const today = new Date();
      const borrow_date = today.toISOString().split('T')[0];
      
      const due = new Date();
      due.setDate(today.getDate() + 14); // 14 days standard borrowing period
      const due_date = due.toISOString().split('T')[0];

      // Update book status
      await dbService.updateBook(book_id, {
        status: 'borrowed',
        holder_id: user_id.toUpperCase(),
        holder_name: user.name || user_name,
        borrow_date,
      });

      // Create borrow record
      const record: BorrowRecord = {
        id: `REC-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        book_id,
        book_title: book.title,
        user_id: user_id.toUpperCase(),
        user_name: user.name || user_name,
        borrow_date,
        due_date,
        status: 'borrowed',
      };

      await dbService.createBorrowRecord(record);
      res.json({ message: '借閱登記成功！', record });
    } catch (err: any) {
      res.status(500).json({ error: err.message || '借閱處理失敗。' });
    }
  });

  // Return Book API (Self Service or Admin)
  app.post('/api/return', async (req, res) => {
    try {
      const { book_id } = req.body;
      if (!book_id) {
        return res.status(400).json({ error: '請提供書籍編號/條碼。' });
      }

      const book = await dbService.getBook(book_id);
      if (!book) {
        return res.status(404).json({ error: '找無此書籍。' });
      }
      if (book.status !== 'borrowed') {
        return res.status(400).json({ error: '此書籍目前並非外借狀態。' });
      }

      // Update book status
      await dbService.updateBook(book_id, {
        status: 'available',
        holder_id: null,
        holder_name: null,
        borrow_date: null,
      });

      // Update borrow record
      const records = await dbService.getBorrowRecords();
      const activeRecord = records.find(r => r.book_id === book_id && r.status === 'borrowed');
      
      if (activeRecord) {
        const todayStr = new Date().toISOString().split('T')[0];
        await dbService.updateBorrowRecord(activeRecord.id, {
          return_date: todayStr,
          status: 'returned',
        });
      }

      res.json({ message: '還書成功！' });
    } catch (err: any) {
      res.status(500).json({ error: err.message || '歸還處理失敗。' });
    }
  });

  // Get Borrow History
  app.get('/api/borrow/history', async (req, res) => {
    try {
      const records = await dbService.getBorrowRecords();
      res.json(records);
    } catch (err) {
      res.status(500).json({ error: '無法讀取借閱歷史紀錄。' });
    }
  });

  // Submit Inventory Audit (點班)
  app.post('/api/audit', async (req, res) => {
    try {
      const { auditor_id, details } = req.body; // details: { book_id: string, status: 'present' | 'missing' }[]
      if (!auditor_id || !details || !Array.isArray(details)) {
        return res.status(400).json({ error: '點班資訊填寫不完整。' });
      }

      const auditor = await dbService.getUser(auditor_id);
      if (!auditor) {
        return res.status(404).json({ error: '找無此點班人員（員工編號）。' });
      }

      const todayStr = new Date().toISOString().split('T')[0];
      let presentCount = 0;
      let missingCount = 0;
      const fullDetails = [];

      for (const item of details) {
        const book = await dbService.getBook(item.book_id);
        if (book) {
          if (item.status === 'present') {
            presentCount++;
            // If the book was marked lost, recover it! If it's borrowed, it stays borrowed but marked present.
            const newStatus = book.status === 'lost' ? 'available' : book.status;
            await dbService.updateBook(book.id, {
              last_audit_date: todayStr,
              status: newStatus,
            });
          } else {
            missingCount++;
            // Mark missing books as lost
            await dbService.updateBook(book.id, {
              last_audit_date: todayStr,
              status: 'lost',
            });
          }
          fullDetails.push({
            book_id: book.id,
            title: book.title,
            status: item.status,
          });
        }
      }

      const newAudit: AuditRecord = {
        id: `AUD-${Date.now()}`,
        audit_date: todayStr,
        auditor_id: auditor.id,
        auditor_name: auditor.name,
        total_books: details.length,
        present_books: presentCount,
        missing_books: missingCount,
        details: fullDetails,
      };

      const savedAudit = await dbService.createAuditRecord(newAudit);
      res.json({ message: '點班清冊已成功登載並更新庫存！', audit: savedAudit });
    } catch (err: any) {
      res.status(500).json({ error: err.message || '提交點班紀錄失敗。' });
    }
  });

  // Get Inventory Audit History
  app.get('/api/audit', async (req, res) => {
    try {
      const records = await dbService.getAuditRecords();
      res.json(records);
    } catch (err) {
      res.status(500).json({ error: '無法讀取點班紀錄。' });
    }
  });

  // Export Borrowing/Returning Records in a custom period (JSON formatting)
  app.get('/api/export', async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      if (!startDate || !endDate) {
        return res.status(400).json({ error: '請指定起始與結束日期。' });
      }

      const records = await dbService.getBorrowRecords();
      const filtered = records.filter(r => {
        const date = r.borrow_date; // We filter by borrowing date range
        return date >= (startDate as string) && date <= (endDate as string);
      });

      res.json(filtered);
    } catch (err) {
      res.status(500).json({ error: '匯出紀錄失敗。' });
    }
  });

  // --- VITE MIDDLEWARE INTERACTION ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express SQL Server running on port ${PORT}`);
  });
}

startServer();
